package sample;

import javafx.animation.*;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.MenuButton;
import javafx.scene.control.ProgressBar;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.*;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.awt.*;
import javafx.scene.control.TextField;
import java.io.IOException;
import java.net.URL;
import java.util.Collections;
import java.util.ResourceBundle;
import java.util.concurrent.TimeUnit;

public class LevelSceneController implements Initializable {

    private int sunToken = 0;

    @FXML
    private Pane PeaMainPane;

    @FXML
    private AnchorPane MainPain;

    @FXML
    private MenuButton menu;

    @FXML
    private ProgressBar timer;

    @FXML
    private ImageView sun;

    @FXML
    private ImageView Zombie1;
    private ImageView[] ZV = new ImageView[5];

    @FXML
    private Image[] ZI = new Image[5];

    @FXML
    private ImageView balloonZombie;

    @FXML
    private ImageView coneZombie;

    @FXML
    private ImageView sun1;

    @FXML
    private ImageView sun2;

    @FXML
    private ImageView sun3;

    @FXML
    private TextField sunPoints ;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        Timeline timeline = new Timeline(
                new KeyFrame(Duration.minutes(0), new KeyValue(timer.progressProperty(), 0)),
                new KeyFrame(Duration.minutes(0.5), new KeyValue(timer.progressProperty(), 1))
        );
        timeline.setCycleCount(Animation.INDEFINITE);
        timeline.play();

        TranslateTransition ZombTrans = new TranslateTransition();
        ZombTrans.setNode(Zombie1);
        ZombTrans.setToX(-500);
        ZombTrans.setDuration(Duration.seconds(10));
        ZombTrans.setCycleCount(500);
        ZombTrans.play();

        TranslateTransition BalloonZombTrans = new TranslateTransition();
        BalloonZombTrans.setNode(balloonZombie);
        BalloonZombTrans.setToX(-500);
        BalloonZombTrans.setDuration(Duration.seconds(10));
        BalloonZombTrans.setCycleCount(500);
        BalloonZombTrans.play();

        TranslateTransition ConeZombTrans = new TranslateTransition();
        ConeZombTrans.setNode(coneZombie);
        ConeZombTrans.setToX(-500);
        ConeZombTrans.setDuration(Duration.seconds(10));
        ConeZombTrans.setCycleCount(500);
        ConeZombTrans.play();

//        for(int i = 0; i < 5; i ++){
//            ZI[i] = new Image(getClass().getResource("/Images/FlagZombie.gif").toExternalForm());
//            ZV[i] = new ImageView(ZI[i]);
////            this.MainPain.getChildren().add(ZV[i]);
//        }

        TranslateTransition SunTrans = new TranslateTransition();
        SunTrans.setNode(sun);
        SunTrans.setToY(500);
        SunTrans.setDuration(Duration.seconds(10));
        SunTrans.setCycleCount(500);
        SunTrans.play();

        TranslateTransition Sun1Trans = new TranslateTransition();
        Sun1Trans.setNode(sun1);
        Sun1Trans.setToY(500);
        Sun1Trans.setDuration(Duration.seconds(10));
        Sun1Trans.setCycleCount(500);
        Sun1Trans.play();

        TranslateTransition Sun2Trans = new TranslateTransition();
        Sun2Trans.setNode(sun2);
        Sun2Trans.setToY(500);
        Sun2Trans.setDuration(Duration.seconds(20));
        Sun2Trans.setCycleCount(500);
        Sun2Trans.play();

        TranslateTransition Sun3Trans = new TranslateTransition();
        Sun3Trans.setNode(sun3);
        Sun3Trans.setToY(500);
        Sun3Trans.setDuration(Duration.seconds(10));
        Sun3Trans.setCycleCount(500);
        Sun3Trans.play();
    }

    @FXML
    void sunDisappear_onClick(MouseEvent event){
        ImageView sunImage = (ImageView) event.getSource();
        sunImage.setVisible(false);
        sunToken += 25;
        String points = Integer.toString(sunToken);
        sunPoints.setText(points);
    }

    @FXML
    void plantDragDetected(MouseEvent event) {
        ImageView PlantCard = (ImageView) event.getSource();
        Dragboard db = PlantCard.startDragAndDrop(TransferMode.ANY);
        ClipboardContent cb = new ClipboardContent();
        switch (PlantCard.getId()){
            case "PlantCard1" : cb.putString("/Images/Pea shooter.gif");break;
            case "PlantCard2" : cb.putString("/Images/Sunflower.png");break;
            case "PlantCard3" : cb.putString("/Images/Walnut.png");break;
            case "PlantCard4" : cb.putString("/Images/CherryBomb.png");break;
        }
        db.setContent(cb);
        event.consume();
    }
    @FXML
    void plantDraggingOver(DragEvent event) {
        if(event.getDragboard().hasString()){
            event.acceptTransferModes(TransferMode.ANY);
        }
    }
    @FXML
    void plantDropped(DragEvent event) {
        ImageView cell = (ImageView) event.getSource();
        if(cell.getImage() != null){
            System.out.println("Plant already present!");
        }
        else {
            cell.setImage(new Image(getClass().getResourceAsStream(event.getDragboard().getString())));
            if(event.getDragboard().getString().equals("/Images/Pea shooter.gif")) {

                Image peaImage = new Image((getClass().getResourceAsStream("/Images/pea.png")));

                ImageView pea = new ImageView(peaImage);
                pea.setFitHeight(10);
                pea.setFitWidth(10);
                //            Scene s = cell.getScene();
                TranslateTransition T = new TranslateTransition();
                T.setNode(pea);
                T.setToX(500);

                T.setDuration(Duration.seconds(5));
                T.setCycleCount(500);
                T.play();
                Pane p = new Pane(pea);
                System.out.println(cell.getLocalToSceneTransform().getTx());
                System.out.println(cell.getLocalToSceneTransform().getTy());
                p.setLayoutX(cell.getLocalToSceneTransform().getTx() + 20);
                p.setLayoutY(cell.getLocalToSceneTransform().getTy() + 20);
                PeaMainPane.getChildren().add(p);
                double ZombPosX[] = {Zombie1.getLocalToSceneTransform().getTx(), coneZombie.getLocalToSceneTransform().getTx(), balloonZombie.getLocalToSceneTransform().getTx()};
                double ZombPosY[] = {Zombie1.getLocalToSceneTransform().getTy(), coneZombie.getLocalToSceneTransform().getTy(), balloonZombie.getLocalToSceneTransform().getTy()};
                for(int i = 0; i < 3; i ++){
                    if(p.getLocalToSceneTransform().getTx() == ZombPosX[i] && p.getLocalToSceneTransform().getTy() == ZombPosY[i]){
                        p.setLayoutX(-10);
                    }
                }

            }
        }
    }

    public void changeScene_mainMenu(ActionEvent event) throws IOException {
        Parent new_parent = FXMLLoader.load(getClass().getResource("MainMenu.fxml"));
        Scene new_scene = new Scene(new_parent);
        Stage old_stage = (Stage) menu.getScene().getWindow();
        old_stage.setScene(new_scene);
    }
}
